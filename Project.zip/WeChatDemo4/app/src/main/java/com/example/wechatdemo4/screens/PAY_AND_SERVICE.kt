package com.example.wechatdemo4.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.wechatdemo4.R
import com.example.wechatdemo4.navigation.NavRoutes


@Composable
fun PAY_AND_SERVICE(navController: NavController) {
    Main2(navController =navController)
}
@Composable
fun Membership(modifier: Modifier= Modifier,navController :NavController) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(Card_heights.dp)
            .width(Card_widths.dp),
        shape = RectangleShape,
        colors = CardDefaults.cardColors(
            containerColor = Color.White,
        )
    ) {
        Row(
            modifier = Modifier
                .padding(13.dp)
                .fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        )

        {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.mebership_icon),
                    null,
                )
                Spacer(modifier = modifier.size(14.dp))

                Text(text = "Membership Cards",
                    fontSize = 16.sp,
                    fontWeight = FontWeight(400))
            }

            Image(painter = painterResource(id=R.drawable.chevron_right),
                contentDescription = null,
            )
        }
    }
}
@Composable
fun OffersAndGiftCards(modifier: Modifier= Modifier,navController :NavController) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(Card_heights.dp)
            .width(Card_widths.dp),
        shape = RectangleShape,
        colors = CardDefaults.cardColors(
            containerColor = Color.White,
        )
    ) {
        Row(
            modifier = Modifier
                .padding(13.dp)
                .fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        )

        {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.offersandgiftcard_icon),
                    null,
                )
                Spacer(modifier = modifier.size(14.dp))

                Text(text = "Offers & Gift Cards",
                    fontSize = 16.sp,
                    fontWeight = FontWeight(400))
            }

            Image(painter = painterResource(id=R.drawable.chevron_right),
                contentDescription = null,
            )
        }
    }
}
@Composable
fun TicketsAndLicenses(modifier: Modifier= Modifier,navController :NavController) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(Card_heights.dp)
            .width(Card_widths.dp),
        shape = RectangleShape,
        colors = CardDefaults.cardColors(
            containerColor = Color.White,
        )
    ) {
        Row(
            modifier = Modifier
                .padding(13.dp)
                .fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        )

        {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.tickets_icon),
                    null,
                )
                Spacer(modifier = modifier.size(14.dp))

                Text(text = "Tickets & Licenses",
                    fontSize = 16.sp,
                    fontWeight = FontWeight(400))
            }

            Image(painter = painterResource(id=R.drawable.chevron_right),
                contentDescription = null,
            )
        }
    }
}
@Composable
//@Preview(showBackground = true)  //可预览标签
fun Groups2(modifier: Modifier= Modifier,navController :NavController){
    Column(
        modifier = Modifier.fillMaxWidth(), //填充屏幕
        verticalArrangement = Arrangement.spacedBy(0.dp)

    ) {
        Membership(modifier = Modifier,navController =navController)
        Spacer(modifier = Modifier.size(11.dp))
        OffersAndGiftCards(modifier = Modifier,navController =navController)
        TicketsAndLicenses(modifier = Modifier,navController =navController)
    }
}
@Composable
//@Preview
fun Main2(modifier: Modifier= Modifier,navController :NavController){
    Column(
        modifier = Modifier
            .fillMaxSize() // 占满全屏
            .clip(RoundedCornerShape(16.dp)) //切角
            .background(Color(242, 242, 242)), // 背景为灰色
    ){
        Box(
            modifier = Modifier.fillMaxWidth()
                .background(Color(242,242,242))
                .size(96.dp)
        )
        {

            ImageButton_(navController = navController) //缺少防抖功能

            Text(text="Cards & Offers",
                fontSize = 18.sp,
                fontWeight = FontWeight(400),
                modifier=Modifier.offset(138.dp,60.dp))


            Image(painter = painterResource(id=R.drawable.expand_left_icon),
                null,
                modifier=Modifier.offset(364.dp,58.dp))

        }

        Groups2(modifier=Modifier,navController= navController)
    }

}
//图形化按钮
@Composable
fun ImageButton_(
    navController: NavController,
) {
    Image(
        painter = painterResource(id = R.drawable.expand_left__1_icon), // 加载 drawable 图标
        contentDescription = null, // 如果是装饰性图标可以为 null
        modifier = Modifier
            .offset(8.dp,59.dp)
            .clickable {  navController.popBackStack() } // 点击事件
    )
}


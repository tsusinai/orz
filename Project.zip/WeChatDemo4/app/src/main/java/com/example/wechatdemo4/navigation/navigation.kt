package com.example.wechatdemo4.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

//导入页面
import com.example.wechatdemo4.screens.HomeScreen
import com.example.wechatdemo4.screens.PAY_AND_SERVICE

object NavRoutes {   //导航常数
    const val HOME = "home" //封装导航常量
    const val PAY_AND_SERVICE = "pas"
}


@Composable  //导航控制
fun MyNavHost(navController: NavHostController){
    NavHost(
        navController = navController,
        startDestination= NavRoutes.HOME //主页面
    ){
        composable(NavRoutes.HOME){
            HomeScreen(navController)  //目标地址：主界面
        }
        composable(NavRoutes.PAY_AND_SERVICE){
            PAY_AND_SERVICE(navController) //目标地址：PAS
        }
    }
}



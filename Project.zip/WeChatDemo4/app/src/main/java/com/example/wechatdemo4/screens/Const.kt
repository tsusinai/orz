package com.example.wechatdemo4.screens

const val Card_heights=64
const val Card_widths=402